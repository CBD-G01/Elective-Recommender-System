# Course-Recommender-System
A recommendation system that would provide ranked list of elective courses with preditcted grades to a student on the basis of his previous performance, interest etc.
